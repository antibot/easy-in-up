=== Plugin Name ===
Contributors: antibot, respect_men@mail.ru
Donate link: http://adventurebit.com/
Tags: login widget, ajax, authorization, registration
Requires at least: 2.7
Tested up to: 3.3
Stable tag: 4.3

Easy Registration/Authorization widget for wordpress. You can easily log in, register and password recovery with AJAX.

== Description ==

Easy Registration/Authorization widget for wordpress is for sites that need user logins or registrations and would like to avoid the normal wordpress login pages, this plugin adds the capability of placing a login widget in the sidebar with bounds AJAX login effects.
Some of the features:
AJAX Login without refreshing your screen.
AJAX Registration without refreshing your screen.
AJAX Registration Password retrieval without refreshing your screen.

Automatic AJAX error output for each field.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `EasyInUp` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to your widgets and us it!

== Frequently Asked Questions ==

= This easy to use? =

Yes, this plugin is very easy to use!

== Screenshots ==

1. Site member
2. Authorization form
2. Registration form
2. Forgot form
2. Admin widget form

== Changelog ==

= 1.0 =
* First version

== Upgrade Notice ==

= 1.0 =
Test and remove all bug
